from sqlalchemy import create_engine, text

DATABASE_URL = "mssql+pyodbc://CloudSA8dc07d54:Admin%40123@attendance-server-nadeem01.database.windows.net/attendance_db?driver=ODBC+Driver+18+for+SQL+Server"
engine = create_engine(DATABASE_URL)

with engine.connect() as conn:
    print("----- TABLES -----")
    tables = conn.execute(text("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE'")).fetchall()
    for table in tables:
        print(f"Table: {table[0]}")
        cols = conn.execute(text(f"SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='{table[0]}'")).fetchall()
        for col in cols:
            print(f"  - {col[0]} ({col[1]})")
        print()
