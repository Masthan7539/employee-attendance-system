from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from jose import jwt
from datetime import datetime
from fastapi.middleware.cors import CORSMiddleware
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig
import random

app = FastAPI()

# ================= CORS =================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ================= DATABASE =================
DATABASE_URL = "mssql+pyodbc://CloudSA8dc07d54:Admin%40123@attendance-server-nadeem01.database.windows.net/attendance_db?driver=ODBC+Driver+18+for+SQL+Server"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

# ================= EMAIL CONFIG =================
conf = ConnectionConfig(
    MAIL_USERNAME="mohammednadeemb4u@gmail.com",
    MAIL_PASSWORD="vdrv pvmt nzzr vyii",
    MAIL_FROM="mohammednadeemb4u@gmail.com",
    MAIL_PORT=587,
    MAIL_SERVER="smtp.gmail.com",
    MAIL_STARTTLS=True,
    MAIL_SSL_TLS=False,
)
# ================= OTP STORE =================
otp_store = {}

# ================= AUTH =================
SECRET_KEY = "secret123"
ALGORITHM = "HS256"

# ================= OFFICE LOCATION =================
OFFICE_LAT = 16.442049165496975
OFFICE_LON = 80.62259459516072
MAX_DISTANCE_METERS = 5000   # allowed radius

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()
# ================= CREATE OWNER =================
def create_owner():
    db = SessionLocal()

    existing = db.execute(
        text("SELECT * FROM users WHERE username='nadeem1234'")
    ).fetchone()

    if not existing:
        db.execute(
            text("""
                INSERT INTO users (username, password, role, company_id, department, email)
                VALUES (:u, :p, 'owner', NULL, 'admin', 'owner@gmail.com')
            """),
            {
                "u": "nadeem1234",
                "p": pwd_context.hash("nadeem1234")
            }
        )
        db.commit()

    db.close()

create_owner()

# ================= HELPER =================
def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    return jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])

import math

def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371000  # meters

    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)

    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1-a))

# ================= TEST =================
@app.get("/")
def test_db():
    db = SessionLocal()
    try:
        db.execute(text("SELECT 1"))
        return {"message": "DB Connected Successfully ✅"}
    except Exception as e:
        return {"error": str(e)}
    finally:
        db.close()

# ================= REGISTER =================
@app.post("/register-company")
def register_company(company_name: str, username: str, password: str, department:str,email: str):
    db = SessionLocal()

    hashed = pwd_context.hash(password[:72])

    result = db.execute(
        text("INSERT INTO companies (name) OUTPUT INSERTED.id VALUES (:name)"),
        {"name": company_name},
    )
    company_id = result.fetchone()[0]

    db.execute(
        text("""
            INSERT INTO users (username, password, role, company_id,department, email)
            VALUES (:u, :p, 'hr', :c, :d, :e)
        """),
        {"u": username, "p": hashed, "c": company_id, "d": department, "e": email},
    )

    db.commit()
    db.close()

    return {"message": "Company + HR created successfully"}

# ================= LOGIN =================
@app.post("/login")
def login(username: str, password: str):
    db = SessionLocal()

    user = db.execute(
        text("""
            SELECT u.*, c.name as company_name 
            FROM users u
            LEFT JOIN companies c ON u.company_id = c.id
            WHERE u.username=:u
        """),
        {"u": username},
    ).fetchone()

    if not user or not pwd_context.verify(password, user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = jwt.encode(
        {
            "sub": user.username,
            "role": user.role,
            "company_id": user.company_id,
            "company_name": user.company_name
        },
        SECRET_KEY,
        algorithm=ALGORITHM,
    )

    db.close()

    return {
        "access_token": token,
        "role": user.role,
        "company_name": user.company_name
    }


# ================= ADD EMPLOYEE =================
@app.post("/add-employee")
def add_employee(username: str, password: str, department: str, email: str, user=Depends(get_current_user)):
    db = SessionLocal()

    if user["role"] != "hr":
        raise HTTPException(status_code=403)

    db.execute(
        text("""
            INSERT INTO users (username, password, role, company_id, department, email)
            VALUES (:u, :p, 'employee', :c, :d, :e)
        """),
        {"u": username, "p": pwd_context.hash(password), "c": user["company_id"], "d": department, "e": email},
    )

    db.commit()
    db.close()

    return {"message": "Employee added"}

# ================= GET EMPLOYEES =================
@app.get("/employees")
def get_employees(user=Depends(get_current_user)):
    db = SessionLocal()

    data = db.execute(text("""
    SELECT u.username,
    CASE 
        WHEN a.id IS NULL THEN 'Inactive'
        WHEN a.check_out IS NULL THEN 'Active'
    ELSE 'Inactive'
    END as status
    FROM users u
    LEFT JOIN attendance a 
    ON a.id = (
        SELECT TOP 1 id 
        FROM attendance 
        WHERE user_id = u.id 
        ORDER BY check_in DESC
    )
    WHERE u.company_id=:c AND u.role='employee'
"""), {"c": user["company_id"]}).fetchall()

    db.close()

    return [
        {
            "username": r[0],
            "status": r[1]
        }
        for r in data
    ]
# ================= DELETE EMPLOYEE =================
@app.delete("/delete-employee")
def delete_employee(username: str, user=Depends(get_current_user)):
    db = SessionLocal()

    if user["role"] != "hr":
        raise HTTPException(status_code=403, detail="Not allowed")

    # 🔥 get user id first
    emp = db.execute(
        text("SELECT id FROM users WHERE username=:u AND company_id=:c"),
        {"u": username, "c": user["company_id"]}
    ).fetchone()

    if not emp:
        raise HTTPException(status_code=404, detail="User not found")

    # ✅ STEP 1: DELETE attendance first
    db.execute(
        text("DELETE FROM attendance WHERE user_id=:id"),
        {"id": emp.id}
    )

    # ✅ STEP 2: DELETE user
    db.execute(
        text("DELETE FROM users WHERE id=:id"),
        {"id": emp.id}
    )

    db.commit()
    db.close()

    return {"message": "Employee deleted"}


# ================= CHECK-IN =================
@app.post("/check-in")
def check_in(lat: float, lon: float, user=Depends(get_current_user)):
    db = SessionLocal()

    u = db.execute(
        text("SELECT id FROM users WHERE username=:u"),
        {"u": user["sub"]},
    ).fetchone()

    if not u:
        raise HTTPException(status_code=404)

    already = db.execute(
        text("""
            SELECT id FROM attendance
            WHERE user_id=:uid AND CAST(check_in AS DATE)=CAST(GETDATE() AS DATE)
        """),
        {"uid": u.id},
    ).fetchone()

    if already:
        raise HTTPException(status_code=400, detail="Already checked in")

    rule = db.execute(
        text("SELECT * FROM attendance_rules WHERE company_id=:c"),
        {"c": user["company_id"]}
    ).fetchone()

    now = datetime.now()
    status = "Present"

    # ⏰ Late logic (same as before)
    if rule:
        start = datetime.strptime(str(rule.check_in_start), "%H:%M:%S").time()
        end = datetime.strptime(str(rule.check_in_end), "%H:%M:%S").time()

        if now.time() > end:
            status = "Late"

    # 🔥 NEW: Distance check (Company wise)
    company = db.execute(
        text("SELECT latitude, longitude FROM companies WHERE id=:c"),
        {"c": user["company_id"]}
    ).fetchone()

    if company and company.latitude is not None and company.longitude is not None:
        distance = calculate_distance(lat, lon, company.latitude, company.longitude)
        print("Distance:", distance)
        if distance > MAX_DISTANCE_METERS:
            status = "Fraud"
    else:
        distance = calculate_distance(lat, lon, OFFICE_LAT, OFFICE_LON)
        print("Fallback Distance:", distance)
        if distance > MAX_DISTANCE_METERS:
            status = "Fraud"

    # 🔥 UPDATED INSERT (with lat/lon)
    db.execute(
        text("""
            INSERT INTO attendance (user_id, check_in, status, latitude, longitude)
            VALUES (:uid, :t, :s, :lat, :lon)
        """),
        {"uid": u.id, "t": now, "s": status, "lat": lat, "lon": lon},
    )

    db.commit()
    db.close()

    return {"status": status, "distance": distance if 'distance' in locals() else -1}

# ================= CHECK-OUT =================
@app.post("/check-out")
def check_out(user=Depends(get_current_user)):
    db = SessionLocal()

    u = db.execute(
        text("SELECT id FROM users WHERE username=:u"),
        {"u": user["sub"]},
    ).fetchone()

    db.execute(
        text("""
            UPDATE attendance
            SET check_out=:t
            WHERE user_id=:uid AND check_out IS NULL
        """),
        {"uid": u.id, "t": datetime.now()}
    )

    db.commit()
    db.close()

    return {"message": "Checked out"}

# ================= LEADERBOARD =================
@app.get("/leaderboard")
def leaderboard(user=Depends(get_current_user)):
    db = SessionLocal()

    data = db.execute(text("""
        SELECT u.username, COUNT(a.id)
        FROM users u
        LEFT JOIN attendance a ON u.id=a.user_id AND a.status='Present'
        WHERE u.company_id=:c
        GROUP BY u.username
        ORDER BY COUNT(a.id) DESC
    """), {"c": user["company_id"]}).fetchall()

    db.close()
    return [{"name": r[0], "score": r[1]} for r in data]

# ================= INSIGHTS =================
@app.get("/insights")
def insights(user=Depends(get_current_user)):
    db = SessionLocal()

    insights_list = []

    # ================= LATE (>2 times) =================
    late_data = db.execute(text("""
        SELECT u.username, COUNT(*) as cnt
        FROM attendance a
        JOIN users u ON u.id=a.user_id
        WHERE a.status='Late' AND u.company_id=:c
        GROUP BY u.username
        HAVING COUNT(*) > 2
    """), {"c": user["company_id"]}).fetchall()

    for r in late_data:
        insights_list.append(f"{r[0]} is frequently late ⚠️")

    # ================= WEEKLY ABSENT (>2 days) =================
    weekly_absent = db.execute(text("""
        SELECT u.username, COUNT(*) 
        FROM users u
        LEFT JOIN attendance a 
            ON u.id = a.user_id 
            AND DATEPART(WEEK, a.check_in) = DATEPART(WEEK, GETDATE())
        WHERE u.company_id=:c AND u.role='employee'
        GROUP BY u.username
        HAVING COUNT(a.id) < 5   -- assuming 5 working days
    """), {"c": user["company_id"]}).fetchall()

    for r in weekly_absent:
        insights_list.append(f"{r[0]} has high absence this week ❌")

    # ================= MONTHLY ABSENT (>5 days) =================
    monthly_absent = db.execute(text("""
        SELECT u.username, COUNT(*) 
        FROM users u
        LEFT JOIN attendance a 
            ON u.id = a.user_id 
            AND MONTH(a.check_in) = MONTH(GETDATE())
        WHERE u.company_id=:c AND u.role='employee'
        GROUP BY u.username
        HAVING COUNT(a.id) < 20   -- approx working days
    """), {"c": user["company_id"]}).fetchall()

    for r in monthly_absent:
        insights_list.append(f"{r[0]} has poor monthly attendance 📉")

    # ================= FRAUD REPEAT =================
    fraud_data = db.execute(text("""
        SELECT u.username, COUNT(*) 
        FROM attendance a
        JOIN users u ON u.id=a.user_id
        WHERE a.status='Fraud' AND u.company_id=:c
        GROUP BY u.username
        HAVING COUNT(*) > 1
    """), {"c": user["company_id"]}).fetchall()

    for r in fraud_data:
        insights_list.append(f"{r[0]} has multiple fraud attempts 🚨")

    # ================= LOW ATTENDANCE % =================
    low_attendance = db.execute(text("""
        SELECT u.username,
        COUNT(CASE WHEN a.status='Present' THEN 1 END) * 100.0 / COUNT(*) as percentage
        FROM attendance a
        JOIN users u ON u.id=a.user_id
        WHERE u.company_id=:c
        GROUP BY u.username
        HAVING COUNT(*) > 0 AND 
        COUNT(CASE WHEN a.status='Present' THEN 1 END) * 100.0 / COUNT(*) < 50
    """), {"c": user["company_id"]}).fetchall()

    for r in low_attendance:
        insights_list.append(f"{r[0]} has low attendance ({int(r[1])}%) ⚠️")

    db.close()

    return insights_list

@app.get("/my-insights")
def my_insights(user=Depends(get_current_user)):
    db = SessionLocal()

    username = user["sub"]
    messages = []

    # ================= LATE =================
    late = db.execute(text("""
        SELECT COUNT(*) FROM attendance a
        JOIN users u ON u.id=a.user_id
        WHERE u.username=:u AND a.status='Late'
    """), {"u": username}).fetchone()[0]

    if late > 2:
        messages.append("⚠️ You are frequently late")

    # ================= FRAUD =================
    fraud = db.execute(text("""
        SELECT COUNT(*) FROM attendance a
        JOIN users u ON u.id=a.user_id
        WHERE u.username=:u AND a.status='Fraud'
    """), {"u": username}).fetchone()[0]

    if fraud > 1:
        messages.append("🚨 Multiple fraud attempts detected")

    # ================= LOW ATTENDANCE =================
    percent = db.execute(text("""
        SELECT 
        COUNT(CASE WHEN a.status='Present' THEN 1 END)*100.0 / COUNT(*)
        FROM attendance a
        JOIN users u ON u.id=a.user_id
        WHERE u.username=:u
    """), {"u": username}).fetchone()[0]

    if percent and percent < 50:
        messages.append(f"⚠️ Your attendance is low ({int(percent)}%)")

    db.close()

    return messages

# ================= FRAUD =================

# ================= FRAUD =================
@app.get("/fraud")
def fraud(user=Depends(get_current_user)):
    db = SessionLocal()

    data = db.execute(text("""
        SELECT u.username, a.latitude, a.longitude
        FROM attendance a
        JOIN users u ON u.id = a.user_id
        WHERE a.status = 'Fraud'
        AND u.company_id = :c
    """), {"c": user["company_id"]}).fetchall()

    db.close()

    return [
        {
            "name": r[0],
            "lat": r[1],
            "lon": r[2]
        }
        for r in data
    ]

# ================= SET RULES =================
@app.post("/set-rules")
def set_rules(check_in_start: str, check_in_end: str, check_out_time: str, user=Depends(get_current_user)):
    db = SessionLocal()

    db.execute(
        text("DELETE FROM attendance_rules WHERE company_id=:c"),
        {"c": user["company_id"]}
    )

    db.execute(
        text("""
            INSERT INTO attendance_rules (company_id, check_in_start, check_in_end, check_out_time)
            VALUES (:c, :s, :e, :o)
        """),
        {"c": user["company_id"], "s": check_in_start, "e": check_in_end, "o": check_out_time}
    )

    db.commit()
    db.close()

    return {"message": "Rules saved"}

# ================= GET RULES =================
@app.get("/rules")
def get_rules(user=Depends(get_current_user)):
    db = SessionLocal()

    rule = db.execute(
        text("""
            SELECT check_in_start, check_in_end, check_out_time
            FROM attendance_rules
            WHERE company_id=:c
        """),
        {"c": user["company_id"]}
    ).fetchone()

    db.close()

    if not rule:
        return {"start": "", "end": "", "out": ""}

    return {
        "start": str(rule[0]),
        "end": str(rule[1]),
        "out": str(rule[2])
    }

# ================= MY ATTENDANCE =================
@app.get("/my-attendance")
def my_attendance(user=Depends(get_current_user)):
    db = SessionLocal()

    data = db.execute(
        text("""
            SELECT check_in, check_out, status
            FROM attendance a
            JOIN users u ON u.id=a.user_id
            WHERE u.username=:u
            ORDER BY check_in DESC
        """),
        {"u": user["sub"]}
    ).fetchall()

    db.close()

    return [
        {
            "check_in": str(r[0]),
            "check_out": str(r[1]) if r[1] else None,
            "status": r[2]
        }
        for r in data
    ]
# ================= TODAY SUMMARY =================
@app.get("/today-summary")
def today_summary(user=Depends(get_current_user)):
    db = SessionLocal()

    data = db.execute(text("""
        SELECT status, COUNT(*) 
        FROM attendance a
        JOIN users u ON u.id = a.user_id
        WHERE u.company_id=:c
        AND CAST(a.check_in AS DATE) = CAST(GETDATE() AS DATE)
        GROUP BY status
    """), {"c": user["company_id"]}).fetchall()
    total_users = db.execute(text("""
    SELECT COUNT(*) 
    FROM users 
    WHERE company_id=:c AND role='employee'
"""), {"c": user["company_id"]}).fetchone()[0]

    result = {"Present": 0, "Absent": 0, "Late": 0}

    for row in data:
        result[row[0]] = row[1]



    db.close()

    return {
        "total": total_users,
        "present": result["Present"],
        "absent": total_users - result["Present"] - result["Late"],
        "late": result["Late"]
    }
@app.get("/owner/companies")
def get_companies(user=Depends(get_current_user)):
    if user["role"] != "owner":
        raise HTTPException(status_code=403)

    db = SessionLocal()

    data = db.execute(text("""
        SELECT c.id, c.name, COUNT(u.id) as total_employees
        FROM companies c
        LEFT JOIN users u ON u.company_id = c.id AND u.role='employee'
        GROUP BY c.id, c.name
    """)).fetchall()

    db.close()

    return [
        {
            "id": r[0],
            "name": r[1],
            "employees": r[2]
        }
        for r in data
    ]
@app.delete("/owner/delete-company")
def delete_company(company_id: int, user=Depends(get_current_user)):
    if user["role"] != "owner":
        raise HTTPException(status_code=403)

    db = SessionLocal()

    # delete attendance
    db.execute(text("""
        DELETE FROM attendance 
        WHERE user_id IN (
            SELECT id FROM users WHERE company_id=:c
        )
    """), {"c": company_id})

    # delete users
    db.execute(
        text("DELETE FROM users WHERE company_id=:c"),
        {"c": company_id}
    )

    # delete company
    db.execute(
        text("DELETE FROM companies WHERE id=:c"),
        {"c": company_id}
    )

    db.commit()
    db.close()

    return {"message": "Company deleted"}

# ================= DEPARTMENT STATS =================
@app.get("/attendance/today/department-summary")
def today_department_summary(user=Depends(get_current_user)):
    db = SessionLocal()

    data = db.execute(text("""
        SELECT u.department,
        COUNT(DISTINCT CASE WHEN a.status='Present' THEN u.id END)*100.0 / 
        NULLIF(COUNT(DISTINCT u.id),0)
        FROM users u
        LEFT JOIN attendance a ON u.id=a.user_id AND CAST(a.check_in AS DATE) = CAST(GETDATE() AS DATE)
        WHERE u.company_id=:c AND u.role='employee'
        GROUP BY u.department
    """), {"c": user["company_id"]}).fetchall()

    db.close()

    return [
        {"department": r[0], "attendancePercentage": float(r[1] or 0)}
        for r in data
    ]


# ================= ATTENDANCE TREND =================
@app.get("/attendance/weekly-trend")
def weekly_trend(user=Depends(get_current_user)):
    from datetime import datetime, timedelta
    db = SessionLocal()

    today = datetime.now().date()
    monday = today - timedelta(days=today.weekday())
    days = [(monday + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(6)]

    trend_map = {day: 0 for day in days}

    data = db.execute(text("""
        SELECT CAST(a.check_in AS DATE) as day,
        COUNT(DISTINCT a.user_id)
        FROM attendance a
        JOIN users u ON u.id=a.user_id
        WHERE u.company_id=:c AND a.status='Present'
        AND CAST(a.check_in AS DATE) >= :start_date AND CAST(a.check_in AS DATE) <= :end_date
        GROUP BY CAST(a.check_in AS DATE)
    """), {"c": user["company_id"], "start_date": days[0], "end_date": days[-1]}).fetchall()

    db.close()

    for r in data:
        day_str = str(r[0])
        if day_str in trend_map:
            trend_map[day_str] = r[1]

    return [{"date": day, "presentCount": trend_map[day]} for day in days]
# ================= SEND OTP =================
@app.post("/send-otp")
async def send_otp(email: str):
    db = SessionLocal()

    user = db.execute(
        text("SELECT id FROM users WHERE email=:e"),
        {"e": email}
    ).fetchone()

    if not user:
        raise HTTPException(status_code=404, detail="Email not found")

    otp = str(random.randint(100000, 999999))
    otp_store[email] = otp

    message = MessageSchema(
        subject="Your OTP Code",
        recipients=[email],
        body=f"Your OTP is {otp}",
        subtype="plain"
    )

    fm = FastMail(conf)
    await fm.send_message(message)

    return {"message": "OTP sent"}


# ================= RESET PASSWORD =================
@app.post("/reset-password")
def reset_password(email: str, otp: str, new_password: str):
    db = SessionLocal()

    if otp_store.get(email) != otp:
        raise HTTPException(status_code=400, detail="Invalid OTP")

    db.execute(
        text("""
            UPDATE users
            SET password=:p
            WHERE email=:e
        """),
        {"p": pwd_context.hash(new_password), "e": email}
    )

    db.commit()
    db.close()

    otp_store.pop(email, None)

    return {"message": "Password updated"}

# ================= SET COMPANY LOCATION =================
@app.post("/set-company-location")
def set_company_location(lat: float, lon: float, user=Depends(get_current_user)):
    db = SessionLocal()
    
    if user["role"] != "hr":
        raise HTTPException(status_code=403, detail="Not authorized")

    db.execute(
        text("UPDATE companies SET latitude=:lat, longitude=:lon WHERE id=:c"),
        {"lat": lat, "lon": lon, "c": user["company_id"]}
    )
    db.commit()
    db.close()
    
    return {"message": "Company location saved"}

# ================= GET COMPANY LOCATION =================
@app.get("/company-location")
def get_company_location(user=Depends(get_current_user)):
    db = SessionLocal()
    
    company = db.execute(
        text("SELECT latitude, longitude FROM companies WHERE id=:c"),
        {"c": user["company_id"]}
    ).fetchone()
    db.close()
    
    if not company or company.latitude is None:
        return {"lat": "", "lon": ""}
        
    return {"lat": company.latitude, "lon": company.longitude}

# ================= LEAVES =================
from pydantic import BaseModel
class LeaveRequest(BaseModel):
    start_date: str
    end_date: str
    reason: str

@app.post("/leaves/request")
def request_leave(req: LeaveRequest, user=Depends(get_current_user)):
    db = SessionLocal()

    u = db.execute(
        text("SELECT id FROM users WHERE username=:u"),
        {"u": user["sub"]},
    ).fetchone()

    if not u:
        raise HTTPException(status_code=404)

    db.execute(
        text("""
            INSERT INTO leave_requests (user_id, start_date, end_date, reason)
            VALUES (:uid, :sd, :ed, :r)
        """),
        {"uid": u.id, "sd": req.start_date, "ed": req.end_date, "r": req.reason}
    )

    db.commit()
    db.close()
    return {"message": "Leave requested"}

@app.get("/leaves/my-requests")
def my_leaves(user=Depends(get_current_user)):
    db = SessionLocal()
    data = db.execute(text("""
        SELECT start_date, end_date, reason, status
        FROM leave_requests lr
        JOIN users u ON lr.user_id = u.id
        WHERE u.username = :u
        ORDER BY start_date DESC
    """), {"u": user["sub"]}).fetchall()
    db.close()

    return [
        {"start_date": str(r[0]), "end_date": str(r[1]), "reason": r[2], "status": r[3]}
        for r in data
    ]

@app.get("/leaves/pending")
def pending_leaves(user=Depends(get_current_user)):
    if user["role"] != "hr":
        raise HTTPException(status_code=403)
    db = SessionLocal()
    data = db.execute(text("""
        SELECT lr.id, u.username, lr.start_date, lr.end_date, lr.reason, lr.status
        FROM leave_requests lr
        JOIN users u ON lr.user_id = u.id
        WHERE u.company_id = :c AND lr.status = 'Pending'
    """), {"c": user["company_id"]}).fetchall()
    db.close()

    return [
        {
            "id": r[0], "username": r[1],
            "start_date": str(r[2]), "end_date": str(r[3]),
            "reason": r[4], "status": r[5]
        }
        for r in data
    ]

@app.put("/leaves/approve/{leave_id}")
def approve_leave(leave_id: int, user=Depends(get_current_user)):
    if user["role"] != "hr":
        raise HTTPException(status_code=403)
    db = SessionLocal()
    
    # 1. Update leave request status to Approved
    db.execute(
        text("UPDATE leave_requests SET status = 'Approved' WHERE id = :id"),
        {"id": leave_id}
    )
    
    # 2. Insert attendance records as 'On Leave'
    leave = db.execute(
        text("SELECT user_id, start_date, end_date FROM leave_requests WHERE id = :id"),
        {"id": leave_id}
    ).fetchone()
    
    if leave:
        from datetime import datetime, timedelta
        # Parse dates
        start = datetime.strptime(str(leave.start_date), "%Y-%m-%d").date()
        end = datetime.strptime(str(leave.end_date), "%Y-%m-%d").date()
        
        current = start
        while current <= end:
            existing = db.execute(
                text("SELECT id FROM attendance WHERE user_id=:uid AND CAST(check_in AS DATE)=:dt"),
                {"uid": leave.user_id, "dt": str(current)}
            ).fetchone()
            
            if not existing:
                db.execute(
                    text("""
                        INSERT INTO attendance (user_id, check_in, status, latitude, longitude)
                        VALUES (:uid, :dt, 'On Leave', 0, 0)
                    """),
                    {"uid": leave.user_id, "dt": current}
                )
            else:
                db.execute(
                    text("UPDATE attendance SET status='On Leave' WHERE id=:aid"),
                    {"aid": existing.id}
                )
            current += timedelta(days=1)
            
    db.commit()
    db.close()
    return {"message": "Approved"}

@app.put("/leaves/reject/{leave_id}")
def reject_leave(leave_id: int, user=Depends(get_current_user)):
    if user["role"] != "hr":
        raise HTTPException(status_code=403)
    db = SessionLocal()
    db.execute(
        text("UPDATE leave_requests SET status = 'Rejected' WHERE id = :id"),
        {"id": leave_id}
    )
    db.commit()
    db.close()
    return {"message": "Rejected"}

# ================= PAYROLL REPORT =================
@app.get("/payroll-report")
def payroll_report(month: int, year: int, user=Depends(get_current_user)):
    if user["role"] != "hr":
        raise HTTPException(status_code=403)
        
    db = SessionLocal()
    data = db.execute(text("""
        SELECT u.username,
               COUNT(CASE WHEN a.status='Present' THEN 1 END) as present,
               COUNT(CASE WHEN a.status='Late' THEN 1 END) as late,
               COUNT(CASE WHEN a.status='On Leave' THEN 1 END) as on_leave
        FROM users u
        LEFT JOIN attendance a ON u.id = a.user_id AND MONTH(a.check_in)=:m AND YEAR(a.check_in)=:y
        WHERE u.company_id = :c AND u.role='employee'
        GROUP BY u.username
    """), {"c": user["company_id"], "m": month, "y": year}).fetchall()
    db.close()
    
    return [
        {
            "username": r[0],
            "present": r[1],
            "late": r[2],
            "on_leave": r[3],
            "absent": max(0, 22 - r[1] - r[2] - r[3]) 
        }
        for r in data
    ]