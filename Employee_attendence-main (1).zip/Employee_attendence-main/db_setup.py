from sqlalchemy import create_engine, text

DATABASE_URL = "mssql+pyodbc://CloudSA8dc07d54:Admin%40123@attendance-server-nadeem01.database.windows.net/attendance_db?driver=ODBC+Driver+18+for+SQL+Server"
engine = create_engine(DATABASE_URL)

def run_migrations():
    with engine.connect() as conn:
        print("Running migrations...")
        
        # 1. Add columns to companies
        try:
            conn.execute(text("ALTER TABLE companies ADD latitude FLOAT"))
            print("Added latitude to companies.")
        except Exception as e:
            print("latitude exists or error:", str(e))
            
        try:
            conn.execute(text("ALTER TABLE companies ADD longitude FLOAT"))
            print("Added longitude to companies.")
        except Exception as e:
            print("longitude exists or error:", str(e))
            
        # 2. Create leave_requests table
        try:
            conn.execute(text("""
                CREATE TABLE leave_requests (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    user_id INT FOREIGN KEY REFERENCES users(id),
                    start_date DATE NOT NULL,
                    end_date DATE NOT NULL,
                    reason VARCHAR(MAX),
                    status VARCHAR(50) DEFAULT 'Pending'
                )
            """))
            print("Created leave_requests table.")
        except Exception as e:
            print("leave_requests config failed or already exists:", str(e))
            
        conn.commit()

if __name__ == "__main__":
    run_migrations()
