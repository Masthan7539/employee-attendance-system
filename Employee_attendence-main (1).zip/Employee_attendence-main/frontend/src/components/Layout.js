import React from 'react';

function Layout({ sidebar, topbar, children }) {
  return (
    <div className="layout-wrapper">
      {sidebar}
      <div className="layout-main">
        {topbar}
        <div className="layout-content">
          {children}
        </div>
      </div>
    </div>
  );
}

export default Layout;
