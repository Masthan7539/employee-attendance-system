import React from 'react';

function SectionContainer({ title, description, children }) {
  return (
    <div className="section-container">
      {(title || description) && (
        <div className="section-header">
          {title && <h3>{title}</h3>}
          {description && <p className="section-description">{description}</p>}
        </div>
      )}
      <div className="section-body">
        {children}
      </div>
    </div>
  );
}

export default SectionContainer;
