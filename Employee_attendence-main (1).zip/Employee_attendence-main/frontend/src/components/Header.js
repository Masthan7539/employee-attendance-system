import React from "react";
import { useNavigate } from "react-router-dom";

function Header() {
  const navigate = useNavigate();

  const company = localStorage.getItem("company_name");
  const role = localStorage.getItem("role");

  // ✅ FIXED logout function
  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  // ✅ DARK MODE TOGGLE
  const toggleTheme = () => {
    document.body.classList.toggle("dark");
  };

  return (
    <div className="header">
      {/* LEFT SIDE */}
      <h2>{company || "Company"}</h2>

      {/* RIGHT SIDE */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <span>
          {role === "hr" ? "HR Panel" : "Employee"}
        </span>

        {/* 🌙 Dark Mode Button */}
        <button className="theme-btn" onClick={toggleTheme}>
          🌙
        </button>

        {/* 🔴 Logout */}
        <button onClick={handleLogout}>
          Logout
        </button>
      </div>
    </div>
  );
}

export default Header;