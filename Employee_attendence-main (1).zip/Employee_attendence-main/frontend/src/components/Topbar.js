import React, { useState, useEffect } from 'react';
import { FiLogOut, FiMoon, FiSun } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

function Topbar({ title }) {
  const navigate = useNavigate();
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  
  const role = localStorage.getItem("role") || "";
  const username = localStorage.getItem("username") || role || "HR";
  const avatarInitials = username.substring(0, 2).toUpperCase();

  useEffect(() => {
    document.documentElement.className = theme;
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("username");
    localStorage.removeItem("company_name");
    navigate("/");
  };

  return (
    <div className="topbar">
      <div className="topbar-title">
        <h2>{title}</h2>
      </div>
      <div className="topbar-actions">
        <button className="theme-toggle" onClick={toggleTheme}>
          {theme === 'light' ? <FiMoon /> : <FiSun />}
        </button>
        <div className="user-profile">
          <div className="avatar">{avatarInitials}</div>
          <button className="logout-btn" onClick={handleLogout}>
            <FiLogOut /> <span>Logout</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Topbar;