import React from "react";
import { MapContainer, TileLayer, Marker, Circle } from "react-leaflet";

function MapView({ lat, lon, officeLat, officeLon }) {
  return (
    <MapContainer
      center={[lat, lon]}
      zoom={15}
      style={{ height: "300px", width: "100%", marginTop: "10px" }}
    >
      <TileLayer
        attribution="&copy; OpenStreetMap"
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {/* Employee Location */}
      <Marker position={[lat, lon]} />

      {/* Office Location */}
      <Marker position={[officeLat, officeLon]} />

      {/* Office Radius */}
      <Circle
        center={[officeLat, officeLon]}
        radius={200}
        pathOptions={{ color: "blue" }}
      />
    </MapContainer>
  );
}

export default MapView;