import React from 'react';

function MetricCard({ title, value, icon, colorClass }) {
  return (
    <div className="metric-card">
      <div className="metric-info">
        <h3>{title}</h3>
        <p>{value}</p>
      </div>
      <div className={`metric-icon ${colorClass}`}>
        {icon}
      </div>
    </div>
  );
}

export default MetricCard;
