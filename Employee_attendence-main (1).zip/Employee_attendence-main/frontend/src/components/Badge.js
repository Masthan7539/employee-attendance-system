import React from 'react';

function Badge({ type, text }) {
  const typeLower = typeof type === 'string' ? type.toLowerCase() : 'default';
  return (
    <span className={`ui-badge badge-${typeLower}`}>
      {text || type}
    </span>
  );
}

export default Badge;
