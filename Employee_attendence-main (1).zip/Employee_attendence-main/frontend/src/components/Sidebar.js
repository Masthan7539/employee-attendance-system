import React from 'react';
import { FiHome, FiUsers, FiFileText, FiSettings, FiUserPlus, FiCalendar } from 'react-icons/fi';

const defaultMenuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: <FiHome /> },
  { id: 'employees', label: 'Employees', icon: <FiUsers /> },
  { id: 'reports', label: 'Reports', icon: <FiFileText /> },
  { id: 'rules', label: 'Rules', icon: <FiSettings /> },
  { id: 'add', label: 'Add Employee', icon: <FiUserPlus /> },
  { id: 'leaves', label: 'Leaves', icon: <FiCalendar /> },
];

function Sidebar({ activeMenu, setActiveMenu, menuItems }) {
  const items = menuItems || defaultMenuItems;

  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon"></div>
        <h2>HR System</h2>
      </div>
      <div className="sidebar-menu">
        {items.map(item => (
          <div 
            key={item.id}
            className={`sidebar-item ${activeMenu === item.id ? 'active' : ''}`}
            onClick={() => setActiveMenu(item.id)}
          >
            <span className="sidebar-icon">{item.icon}</span>
            <span className="sidebar-label">{item.label}</span>
          </div>
        ))}
      </div>
      <div className="sidebar-footer">
        <p>Enterprise Edition</p>
      </div>
    </div>
  );
}

export default Sidebar;