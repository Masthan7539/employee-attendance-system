import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import "./App.css";

// ================= PAGES =================
import Login from "./pages/Login";
import Register from "./pages/Register";
import EmployeeDashboard from "./pages/EmployeeDashboard";
import HRDashboard from "./pages/HRDashboard";
import Employees from "./pages/Employees";
import Reports from "./pages/Reports";
import ForgotPassword from "./pages/ForgotPassword"; 
import OwnerDashboard from "./pages/OwnerDashboard";

// ================= PRIVATE ROUTE =================
const PrivateRoute = ({ children, role }) => {
  const userRole = localStorage.getItem("role");
  const token = localStorage.getItem("token");

  // ❌ Not logged in
  if (!userRole || !token) {
    return <Navigate to="/" replace />;
  }

  // ❌ Wrong role access
  if (role && userRole !== role) {
    return <Navigate to="/" replace />;
  }

  // ✅ Access granted
  return children;
};

// ================= APP COMPONENT =================
function App() {
  return (
    <Router>
      <Routes>

        {/* ================= PUBLIC ROUTES ================= */}
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot" element={<ForgotPassword />} />
        <Route
  path="/owner"
  element={
    <PrivateRoute role="owner">
      <OwnerDashboard />
    </PrivateRoute>
  }
/>

        {/* ================= HR ROUTES ================= */}
        <Route
          path="/hr"
          element={
            <PrivateRoute role="hr">
              <HRDashboard />
            </PrivateRoute>
          }
        />

        <Route
          path="/employees"
          element={
            <PrivateRoute role="hr">
              <Employees />
            </PrivateRoute>
          }
        />

        <Route
          path="/reports"
          element={
            <PrivateRoute role="hr">
              <Reports />
            </PrivateRoute>
          }
        />

        {/* ================= EMPLOYEE ROUTE ================= */}
        <Route
          path="/employee"
          element={
            <PrivateRoute role="employee">
              <EmployeeDashboard />
            </PrivateRoute>
          }
        />

        {/* ================= FALLBACK ROUTE ================= */}
        <Route path="*" element={<Navigate to="/" />} />

      </Routes>
    </Router>
  );
}


export default App;