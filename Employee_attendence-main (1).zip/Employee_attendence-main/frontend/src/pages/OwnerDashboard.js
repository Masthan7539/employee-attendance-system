import React, { useEffect, useState, useCallback } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import "../App.css";

import Layout from "../components/Layout";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import Card from "../components/Card";
import MetricCard from "../components/MetricCard";
import Table from "../components/Table";
import SectionContainer from "../components/SectionContainer";

import { FiBriefcase, FiTrash2, FiUsers } from 'react-icons/fi';

function OwnerDashboard() {
  const [companies, setCompanies] = useState([]);
  const [activeMenu, setActiveMenu] = useState("companies");
  const token = localStorage.getItem("token");

  // ================= MENU ITEMS =================
  const ownerMenuItems = [
    { id: 'companies', label: 'Companies Directory', icon: <FiBriefcase /> }
  ];

  // ================= FETCH COMPANIES =================
  const fetchCompanies = useCallback(async () => {
    try {
      const res = await API.get("/owner/companies", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCompanies(res.data);
    } catch (err) {
      console.error("Error fetching companies:", err);
    }
  }, [token]);

  // ================= DELETE COMPANY =================
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this company? This action cannot be undone.");
    if (!confirmDelete) return;

    try {
      await API.delete(`/owner/delete-company?company_id=${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchCompanies();
    } catch (err) {
      console.error("Delete error:", err);
      alert("Failed to delete company ❌");
    }
  };

  // ================= USE EFFECT =================
  useEffect(() => {
    fetchCompanies();
  }, [fetchCompanies]);

  // ================= SUMMARY =================
  const totalCompanies = companies.length;
  // Make sure c.employees is parsed as an int safely
  const totalEmployees = companies.reduce((acc, c) => acc + (parseInt(c.employees) || 0), 0);

  // ================= TABLE COLUMNS =================
  const companyColumns = [
    { 
      header: "Company Name", 
      key: "name", 
      render: (c) => (
        <div className="avatar-cell">
          <div className="avatar-sm" style={{ backgroundColor: 'var(--primary-color)', color: 'white' }}>
            {c.name.substring(0, 2).toUpperCase()}
          </div>
          <span style={{ fontWeight: 600 }}>{c.name}</span>
        </div>
      )
    },
    { 
      header: "Employee Count", 
      key: "employees", 
      render: (c) => (
        <span style={{ color: 'var(--text-secondary)' }}>
          {c.employees} registered workers
        </span>
      )
    },
    { 
      header: "Action", 
      key: "action", 
      render: (c) => (
        <button
          className="ui-button danger"
          onClick={() => handleDelete(c.id)}
        >
          <FiTrash2 /> Delete
        </button>
      ) 
    }
  ];

  const pageTitles = {
    companies: "Owner Dashboard"
  };

  return (
    <Layout
      sidebar={<Sidebar activeMenu={activeMenu} setActiveMenu={setActiveMenu} menuItems={ownerMenuItems} />}
      topbar={<Topbar title={pageTitles[activeMenu]} />}
    >
      {activeMenu === "companies" && (
        <>
          <SectionContainer title="Enterprise Overview">
            <div className="metrics-grid">
              <MetricCard 
                title="Total Companies" 
                value={totalCompanies} 
                icon={<FiBriefcase />} 
                colorClass="primary" 
              />
              <MetricCard 
                title="Platform Users" 
                value={totalEmployees} 
                icon={<FiUsers />} 
                colorClass="success" 
              />
            </div>
          </SectionContainer>

          <div style={{ marginTop: "32px" }}>
            <SectionContainer title="Client Directory" description="Manage all registered companies connected to the platform.">
              <Card>
                <Table columns={companyColumns} data={companies} />
              </Card>
            </SectionContainer>
          </div>
        </>
      )}
    </Layout>
  );
}

export default OwnerDashboard;