import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPass, setNewPass] = useState("");

  const navigate = useNavigate();

  // ================= SEND OTP =================
  const sendOtp = async () => {
    try {
      if (!email) return alert("Enter email");

      await API.post(`/send-otp?email=${email}`);
      alert("OTP sent to your email 📩");
    } catch (err) {
      alert(err.response?.data?.detail || "Failed to send OTP");
    }
  };

  // ================= RESET PASSWORD =================
  const reset = async () => {
    try {
      if (!email || !otp || !newPass) {
        return alert("Fill all fields");
      }

      await API.post(
        `/reset-password?email=${email}&otp=${otp}&new_password=${newPass}`
      );

      alert("Password reset successful ✅");

      // 👉 redirect to login
      navigate("/");
    } catch (err) {
      alert(err.response?.data?.detail || "Reset failed");
    }
  };

  return (
    <div className="forgot-container">
      <div className="forgot-box">
        <h2>Forgot Password</h2>

        <input
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <button onClick={sendOtp}>Send OTP</button>

        <input
          placeholder="OTP"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
        />

        <input
          type="password"
          placeholder="New Password"
          value={newPass}
          onChange={(e) => setNewPass(e.target.value)}
        />

        <button onClick={reset}>Reset Password</button>
        <p
  style={{
    cursor: "pointer",
    color: "#3b82f6",
    textAlign: "center",
    marginTop: "10px"
  }}
  onClick={() => navigate("/")}
>
  <button onClick={() => navigate("/")} className="secondary-btn">
  Back to Login
</button>
</p>
      </div>
    </div>
  );
}

export default ForgotPassword;