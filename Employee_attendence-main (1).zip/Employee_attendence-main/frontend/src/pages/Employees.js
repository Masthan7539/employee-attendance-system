import React from "react";

function Employees() {
  return (
    <div className="dashboard">
      <h2>Employees Page</h2>
      <p>Here you can manage employees</p>
    </div>
  );
}

export default Employees;