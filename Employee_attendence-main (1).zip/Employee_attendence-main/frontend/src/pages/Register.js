import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import { FaBuilding } from "react-icons/fa";

function Register() {
  const [company, setCompany] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");

  const navigate = useNavigate();

  const handleRegister = async () => {
    try {
      if (!company || !username || !password || !email) {
        return alert("Fill all fields");
      }

      await API.post(
        `/register-company?company_name=${company}&username=${username}&password=${password}&department=HR&email=${email}`
      );

      alert("Company Registered Successfully ✅");
      navigate("/");
    } catch (err) {
      alert("Registration Failed ❌");
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">

        <div className="login-icon">
          <FaBuilding size={40} />
        </div>

        <h2>Register Company</h2>
        <p>Create your company account</p>

        <input
          placeholder="Company Name"
          value={company}
          onChange={(e) => setCompany(e.target.value)}
        />

        <input
          placeholder="HR Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleRegister}>Register Company</button>

        <p
          style={{ cursor: "pointer", color: "#3b82f6" }}
          onClick={() => navigate("/")}
        >
          Already have an account? Login
        </p>
      </div>
    </div>
  );
}

export default Register;