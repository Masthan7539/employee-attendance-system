import React, { useState } from "react";
import { login } from "../services/api";
import { useNavigate } from "react-router-dom";
import { FaBuilding } from "react-icons/fa";
import "../App.css"; // make sure CSS is imported

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      console.log("Sending:", username, password);

      const res = await login({ username, password });

      console.log("FULL RESPONSE:", res);
      console.log("DATA:", res.data);

      if (!res || !res.data || !res.data.access_token) {
        throw new Error("Invalid response from server");
      }

      // ✅ Save token
      localStorage.setItem("token", res.data.access_token);
      localStorage.setItem("role", res.data.role);
      localStorage.setItem("company_name", res.data.company_name);
      localStorage.setItem("username", username);
      

      alert("Login Successful ✅");

      // ✅ Redirect based on role
      // ✅ Redirect based on role
console.log("ROLE:", res.data.role);

if (res.data.role === "hr") {
  navigate("/hr");
} else if (res.data.role === "employee") {
  navigate("/employee");
} else if (res.data.role === "owner") {
  navigate("/owner");
} else {
  alert("Unknown role: " + res.data.role);
}
    }
    catch (err) {
      console.error("LOGIN ERROR:", err);

      if (err.response) {
        console.error("Server Response:", err.response.data);
      }

      alert("Login failed ❌");
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">

        {/* ✅ ICON ADDED HERE */}
        <div className="login-icon">
          <FaBuilding size={40} />
        </div>

        <h2>Enterprise Attendance</h2>
        <p>Sign in to access your dashboard</p>

        <input
          type="text"
          placeholder="Enter your username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter your password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleLogin}>Sign In</button>
        <p
  style={{ cursor: "pointer", color: "blue" }}
  onClick={() => navigate("/forgot")}
>
  Forgot Password?
</p>

        <div className="register-link">
          Don't have an account?{" "}
          <span onClick={() => navigate("/register")}>
            Register your company
          </span>
        </div>
      </div>
    </div>
  );
}

export default Login;