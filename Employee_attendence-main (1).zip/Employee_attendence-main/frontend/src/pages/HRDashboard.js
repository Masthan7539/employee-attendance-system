import React, { useEffect, useState, useCallback } from "react";
import "../App.css";
import API, { deleteEmployee } from "../services/api";
import { setRules } from "../services/api";
import MapView from "../components/MapView";
import * as XLSX from "xlsx";

import Layout from "../components/Layout";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import Card from "../components/Card";
import MetricCard from "../components/MetricCard";
import Badge from "../components/Badge";
import Table from "../components/Table";
import SectionContainer from "../components/SectionContainer";

import { FiUsers, FiCheckCircle, FiXCircle, FiClock, FiUploadCloud } from 'react-icons/fi';

import { Line, Bar } from "react-chartjs-2";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

function HRDashboard() {
  const token = localStorage.getItem("token");

  // ================= RULE STATES =================
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [checkout, setCheckout] = useState("");
  const [comLat, setComLat] = useState("");
  const [comLon, setComLon] = useState("");
  const [pendingLeaves, setPendingLeaves] = useState([]);

  // ================= MENU =================
  const [activeMenu, setActiveMenu] = useState("dashboard");

  // ================= EMPLOYEE STATES =================
  const [employees, setEmployees] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [department, setDepartment] = useState("");
  const [email, setEmail] = useState("");

  const [leaderboard, setLeaderboard] = useState([]);
  const [insights, setInsights] = useState([]);
  const [fraud, setFraud] = useState([]);
  const [summary, setSummary] = useState({
    total: 0,
    present: 0,
    absent: 0,
    late: 0,
  });
  const [deptData, setDeptData] = useState([]);
  const [trendDataApi, setTrendDataApi] = useState([]);


  // ================= SAVE RULES =================
  const handleSaveRules = async () => {
    try {
      await setRules(
        { start, end, out: checkout },
        token
      );
      alert("Rules saved ✅");
    } catch (err) {
      console.error(err);
      alert("Failed ❌");
    }
  };

  // ================= SAVE COMPANY LOCATION =================
  const handleSaveLocation = async () => {
    try {
      await API.post(`/set-company-location?lat=${comLat}&lon=${comLon}`, {}, {
         headers: { Authorization: `Bearer ${token}` }
      });
      alert("Location saved ✅");
    } catch(err) {
      console.error(err);
      alert("Failed to save location ❌");
    }
  };

  // ================= FETCH EMPLOYEES =================
  const fetchEmployees = useCallback(async () => {
    try {
      const res = await API.get("/employees", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEmployees(res.data);
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  // ================= FETCH LEADERBOARD =================
  const fetchLeaderboard = useCallback(async () => {
    try {
      const res = await API.get("/leaderboard", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaderboard(res.data);
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  // ================= FETCH INSIGHTS =================
  const fetchInsights = useCallback(async () => {
    try {
      const res = await API.get("/insights", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setInsights(res.data);
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  // ================= FETCH FRAUD =================
  const fetchFraud = useCallback(async () => {
    try {
      const res = await API.get("/fraud", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFraud(res.data);
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  const fetchRules = useCallback(async () => {
    try {
      const res = await API.get("/rules", {
        headers: { Authorization: `Bearer ${token}` },
      });

      setStart(res.data.start || "");
      setEnd(res.data.end || "");
      setCheckout(res.data.out || "");
    } catch (err) {
      console.error("Failed to fetch rules", err);
    }
  }, [token]);

  const fetchCompanyLocation = useCallback(async () => {
    try {
      const res = await API.get("/company-location", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setComLat(res.data.lat || "");
      setComLon(res.data.lon || "");
    } catch (err) { console.error(err); }
  }, [token]);

  const fetchPendingLeaves = useCallback(async () => {
    try {
      const res = await API.get("/leaves/pending", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPendingLeaves(res.data);
    } catch (err) { console.error(err); }
  }, [token]);

  const fetchSummary = useCallback(async () => {
    try {
      const res = await API.get("/today-summary", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSummary(res.data);
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  const fetchDeptStats = useCallback(async () => {
    try {
      const res = await API.get("/attendance/today/department-summary", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setDeptData(res.data);
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  const fetchTrend = useCallback(async () => {
    try {
      const res = await API.get("/attendance/weekly-trend", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTrendDataApi(res.data);
    } catch (err) {
      console.error(err);
    }
  }, [token]);

  // ================= USE EFFECT =================
  useEffect(() => {
    fetchEmployees();
    fetchLeaderboard();
    fetchInsights();
    fetchFraud();
    fetchRules();
    fetchSummary();
    fetchDeptStats();
    fetchTrend();
    fetchCompanyLocation();
    fetchPendingLeaves();
  }, [
    fetchEmployees,
    fetchLeaderboard,
    fetchInsights,
    fetchFraud,
    fetchRules,
    fetchSummary,
    fetchDeptStats,
    fetchTrend,
    fetchCompanyLocation,
    fetchPendingLeaves
  ]);

  // ================= ADD EMPLOYEE =================
  const handleAddEmployee = async () => {
    try {
      await API.post(
        `/add-employee?username=${username}&password=${password}&department=${department}&email=${email}`,
        {},
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      alert("Employee Added ✅");

      setUsername("");
      setPassword("");
      setDepartment("");
      setEmail("");

      fetchEmployees();
      fetchLeaderboard();
    } catch (err) {
      console.error(err);
      alert("Failed ❌");
    }
  };

  const handleExcelUpload = async (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = async (evt) => {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: "array" });

      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(sheet);

      console.log(jsonData);

      try {
        for (let emp of jsonData) {
          await API.post(
            `/add-employee?username=${emp.username}&password=${emp.password}&department=${emp.department}&email=${emp.email}`,
            {},
            {
              headers: { Authorization: `Bearer ${token}` },
            }
          );
        }

        alert("Bulk Employees Added ✅");
        fetchEmployees();
      } catch (err) {
        console.error(err);
        alert("Upload failed ❌");
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // ================= DELETE EMPLOYEE =================
  const handleDelete = async (username) => {
    try {
      await deleteEmployee(username, token);
      alert("Deleted ✅");
      fetchEmployees();
    } catch (err) {
      console.error(err);
      alert("Delete failed ❌");
    }
  };

  const approveLeave = async (id) => {
    try {
      await API.put(`/leaves/approve/${id}`, {}, { headers: { Authorization: `Bearer ${token}` } });
      alert("Approved ✅");
      fetchPendingLeaves();
    } catch (err) { alert("Failed"); }
  };

  const rejectLeave = async (id) => {
    try {
      await API.put(`/leaves/reject/${id}`, {}, { headers: { Authorization: `Bearer ${token}` } });
      alert("Rejected ❌");
      fetchPendingLeaves();
    } catch (err) { alert("Failed"); }
  };

  const handleExportPayroll = async () => {
    try {
      const now = new Date();
      const res = await API.get(`/payroll-report?month=${now.getMonth() + 1}&year=${now.getFullYear()}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const ws = XLSX.utils.json_to_sheet(res.data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Payroll");
      XLSX.writeFile(wb, `Payroll_Report_${now.getMonth() + 1}_${now.getFullYear()}.xlsx`);
    } catch (err) {
      alert("Failed to run payroll");
    }
  };

  // ================= GRAPH DATA =================
  const departmentData = {
    labels: deptData.map(d => d.department),
    datasets: [
      {
        label: "Attendance %",
        data: deptData.map(d => d.attendancePercentage),
        backgroundColor: "rgba(79, 70, 229, 0.8)",
        borderRadius: 4,
      },
    ],
  };

  const trendData = {
    labels: trendDataApi.map(t => t.date),
    datasets: [
      {
        label: "Attendance Trend",
        data: trendDataApi.map(t => t.presentCount),
        borderColor: "#10b981",
        backgroundColor: "rgba(16, 185, 129, 0.1)",
        tension: 0.4,
        fill: true,
      },
    ],
  };

  // ================= TABLE COLUMNS =================
  const employeeColumns = [
    {
      header: "Employee",
      key: "username",
      render: (emp) => (
        <div className="avatar-cell">
          <div className="avatar-sm">
            {emp.username.substring(0, 2).toUpperCase()}
          </div>
          <span style={{ fontWeight: 500 }}>{emp.username}</span>
        </div>
      ),
    },
    {
      header: "Status",
      key: "status",
      render: (emp) => (
        <Badge
          type={emp.status === "Active" ? "active" : "inactive"}
          text={emp.status}
        />
      ),
    },
    {
      header: "Action",
      key: "action",
      render: (emp) => (
        <button
          className="ui-button danger"
          onClick={() => handleDelete(emp.username)}
        >
          Delete
        </button>
      ),
    },
  ];

  const leaderboardColumns = [
    { header: "Rank", key: "rank", render: (_, idx) => `#${idx + 1}` },
    {
      header: "Name",
      key: "name",
      render: (emp) => <span style={{ fontWeight: 500 }}>{emp.name}</span>,
    },
    {
      header: "Score (Days)",
      key: "score",
      render: (emp) => (
        <Badge type="present" text={`${emp.score} days`} />
      ),
    },
  ];

  const leaveColumns = [
    { header: "Employee", key: "username", render: (l) => <span style={{ fontWeight: 500 }}>{l.username}</span> },
    { header: "From", key: "start_date" },
    { header: "To", key: "end_date" },
    { header: "Reason", key: "reason" },
    {
      header: "Action",
      key: "action",
      render: (l) => (
        <div style={{ display: "flex", gap: "8px" }}>
          <button className="ui-button success" onClick={() => approveLeave(l.id)}>Approve</button>
          <button className="ui-button danger" onClick={() => rejectLeave(l.id)}>Reject</button>
        </div>
      )
    }
  ];

  // Map to nicely display page title in Topbar
  const pageTitles = {
    dashboard: "Overview",
    employees: "Employee Directory",
    reports: "Reports & Insights",
    rules: "Attendance Rules",
    add: "Add Employee",
    leaves: "Leave Management"
  };

  return (
    <Layout
      sidebar={<Sidebar activeMenu={activeMenu} setActiveMenu={setActiveMenu} />}
      topbar={<Topbar title={pageTitles[activeMenu]} />}
    >
      {/* ================= DASHBOARD ================= */}
      {activeMenu === "dashboard" && (
        <>
          <div className="metrics-grid">
            <MetricCard
              title="Total Employees"
              value={summary.total || 0}
              icon={<FiUsers />}
              colorClass="primary"
            />
            <MetricCard
              title="Present Today"
              value={summary.present || 0}
              icon={<FiCheckCircle />}
              colorClass="success"
            />
            <MetricCard
              title="Absent Today"
              value={summary.absent || 0}
              icon={<FiXCircle />}
              colorClass="danger"
            />
            <MetricCard
              title="Late Arrivals"
              value={summary.late || 0}
              icon={<FiClock />}
              colorClass="warning"
            />
          </div>

          <div className="charts-grid">
            <Card title="Department Heatmap">
              <div className="chart-container-inner" style={{ height: "300px" }}>
                <Bar
                  data={departmentData}
                  options={{ maintainAspectRatio: false, responsive: true }}
                />
              </div>
            </Card>

            <Card title="Attendance Trend">
              <div className="chart-container-inner" style={{ height: "300px" }}>
                <Line
                  data={trendData}
                  options={{ maintainAspectRatio: false, responsive: true }}
                />
              </div>
            </Card>
          </div>
        </>
      )}

      {/* ================= EMPLOYEES ================= */}
      {activeMenu === "employees" && (
        <Card title="Registered Employees">
          <Table columns={employeeColumns} data={employees} />
        </Card>
      )}

      {/* ================= REPORTS ================= */}
      {activeMenu === "reports" && (
        <div className="charts-grid">
          <Card title="🏆 Leaderboard">
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '16px' }}>
              <button className="ui-button" onClick={handleExportPayroll}>
                 Export Payroll (Excel)
              </button>
            </div>
            <Table columns={leaderboardColumns} data={leaderboard} />
          </Card>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            <Card title="🧠 Smart Insights">
              {insights.length === 0 ? (
                <p style={{ color: 'var(--text-secondary)' }}>No issues detected</p>
              ) : (
                <ul style={{ paddingLeft: '20px', margin: 0 }}>
                  {insights.map((msg, i) => (
                    <li key={i} style={{ marginBottom: '8px' }}>{msg}</li>
                  ))}
                </ul>
              )}
            </Card>

            <Card title="🚨 Fraud Alerts">
              {fraud.length === 0 ? (
                <p style={{ color: 'var(--text-secondary)' }}>No suspicious activity detected</p>
              ) : (
                fraud.map((f, i) => (
                  <div key={i} className="fraud-alert">
                    <p>
                      {f.name} checked in from a different location
                    </p>
                    <div style={{ borderRadius: '8px', overflow: 'hidden' }}>
                      <MapView
                        lat={f.lat}
                        lon={f.lon}
                        officeLat={16.442049165496975}
                        officeLon={80.62259459516072}
                      />
                    </div>
                  </div>
                ))
              )}
            </Card>
          </div>
        </div>
      )}

      {/* ================= RULES SECTION ================= */}
      {activeMenu === "rules" && (
        <SectionContainer
          title="Attendance Rules"
          description="Configure the default working hours and checkout times for the enterprise."
        >
          <Card>
            <div className="form-grid">
              <div className="input-group">
                <label>Start Time</label>
                <input
                  type="time"
                  className="ui-input"
                  value={start}
                  onChange={(e) => setStart(e.target.value)}
                />
              </div>

              <div className="input-group">
                <label>End Time</label>
                <input
                  type="time"
                  className="ui-input"
                  value={end}
                  onChange={(e) => setEnd(e.target.value)}
                />
              </div>

              <div className="input-group">
                <label>Checkout Target Time</label>
                <input
                  type="time"
                  className="ui-input"
                  value={checkout}
                  onChange={(e) => setCheckout(e.target.value)}
                />
              </div>
            </div>

            <div className="button-container">
              <button className="ui-button" onClick={handleSaveRules}>
                <FiClock /> Save Configurations
              </button>
            </div>
          </Card>

          <Card title="Geofencing Settings">
             <div className="form-grid">
               <div className="input-group">
                 <label>Company Latitude</label>
                 <input className="ui-input" value={comLat} onChange={(e) => setComLat(e.target.value)} />
               </div>
               <div className="input-group">
                 <label>Company Longitude</label>
                 <input className="ui-input" value={comLon} onChange={(e) => setComLon(e.target.value)} />
               </div>
             </div>
             <div className="button-container">
               <button className="ui-button" onClick={handleSaveLocation}>
                 Save Location
               </button>
             </div>
          </Card>
        </SectionContainer>
      )}

      {/* ================= LEAVES ================= */}
      {activeMenu === "leaves" && (
        <SectionContainer title="Leave Requests" description="Review and approve pending employee leaves.">
          <Card>
            {pendingLeaves.length === 0 ? <p style={{color: 'var(--text-secondary)'}}>No pending leave requests.</p> : <Table columns={leaveColumns} data={pendingLeaves} />}
          </Card>
        </SectionContainer>
      )}

      {/* ================= ADD EMPLOYEE ================= */}
      {activeMenu === "add" && (
        <SectionContainer
          title="Onboard Employee"
          description="Add a new team member individually or upload a bulk sheet."
        >
          <Card title="Single Onboarding">
            <div className="form-grid">
              <div className="input-group">
                <label>Username</label>
                <input
                  className="ui-input"
                  placeholder="e.g. jdoe"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="input-group">
                <label>Email Address</label>
                <input
                  className="ui-input"
                  type="email"
                  placeholder="e.g. jdoe@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="input-group">
                <label>Password</label>
                <input
                  type="password"
                  className="ui-input"
                  placeholder="Secure password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="input-group">
                <label>Department</label>
                <input
                  className="ui-input"
                  placeholder="e.g. Engineering"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                />
              </div>
            </div>

            <div className="button-container">
              <button className="ui-button" onClick={handleAddEmployee}>
                <FiUsers /> Complete Registration
              </button>
            </div>
          </Card>

          <Card title="Bulk Onboarding">
            <div className="upload-box">
              <FiUploadCloud size={48} color="var(--primary-color)" />
              <div>
                <p>Upload Excel Sheet</p>
                <span className="upload-text">Supports .xlsx and .xls formats with predefined columns</span>
              </div>
              
              <label className="upload-label">
                Select File
                <input
                  type="file"
                  accept=".xlsx, .xls"
                  onChange={handleExcelUpload}
                />
              </label>
            </div>
          </Card>
        </SectionContainer>
      )}
    </Layout>
  );
}

export default HRDashboard;