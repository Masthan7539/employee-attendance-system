import React from "react";

function Reports() {
  return (
    <div className="dashboard">
      <h2>Reports Page</h2>
      <p>Reports & analytics will be shown here</p>
    </div>
  );
}

export default Reports;