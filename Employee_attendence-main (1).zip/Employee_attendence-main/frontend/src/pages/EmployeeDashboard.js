import React, { useEffect, useState } from "react";
import "../App.css";
import API, { getMyAttendance } from "../services/api";
import { useNavigate } from "react-router-dom";

import Layout from "../components/Layout";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import Card from "../components/Card";
import MetricCard from "../components/MetricCard";
import Badge from "../components/Badge";
import Table from "../components/Table";
import SectionContainer from "../components/SectionContainer";

import { FiHome, FiClock, FiBell, FiCheckCircle, FiXCircle, FiLogOut, FiLogIn } from 'react-icons/fi';

function EmployeeDashboard() {
  const [status, setStatus] = useState("Not Checked In");
  const [attendance, setAttendance] = useState([]);
  const [activeMenu, setActiveMenu] = useState("dashboard");
  const [notifications, setNotifications] = useState([]);

  const token = localStorage.getItem("token");

  // ================= MENU ITEMS =================
  const employeeMenuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <FiHome /> },
    { id: 'history', label: 'Attendance History', icon: <FiClock /> },
    { id: 'notifications', label: 'Notifications', icon: <FiBell /> }
  ];

  // ================= FETCH ATTENDANCE =================
  const fetchAttendance = async () => {
    try {
      const res = await getMyAttendance(token);
      setAttendance(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await API.get("/my-insights", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setNotifications(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAttendance();
    fetchNotifications();
  }, []);

  // ================= CHECK-IN =================
  const handleCheckIn = async () => {
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        try {
          const res = await API.post(
            `/check-in?lat=${lat}&lon=${lon}`,
            {},
            { headers: { Authorization: `Bearer ${token}` } }
          );

          setStatus(`Checked In (${res.data.status}) 📍`);
          fetchAttendance();
        } catch (err) {
          alert(err.response?.data?.detail || "Check-in failed");
        }
      },
      () => {
        alert("Location permission required ❌");
      }
    );
  };

  // ================= CHECK-OUT =================
  const handleCheckOut = async () => {
    try {
      await API.post(
        "/check-out",
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setStatus("Checked Out 🚪");
      fetchAttendance();
    } catch (err) {
      alert("Check-out failed");
    }
  };

  // ================= FORMAT DATE =================
  const formatDate = (date) => {
    if (!date) return "-";
    return date.split(".")[0];
  };

  // ================= SUMMARY =================
  const present = attendance.filter(a => a.status === "Present").length;
  const late = attendance.filter(a => a.status === "Late").length;
  const absent = attendance.filter(a => a.status === "Absent").length;

  const historyColumns = [
    { header: "Check In", key: "check_in", render: (a) => formatDate(a.check_in) },
    { header: "Check Out", key: "check_out", render: (a) => formatDate(a.check_out) },
    { header: "Status", key: "status", render: (a) => (
      <Badge 
        type={a.status === "Late" ? "late" : a.status === "Absent" ? "absent" : "present"} 
        text={a.status} 
      />
    )}
  ];

  const pageTitles = {
    dashboard: "My Dashboard",
    history: "Attendance History",
    notifications: "My Notifications"
  };

  return (
    <Layout 
      sidebar={<Sidebar activeMenu={activeMenu} setActiveMenu={setActiveMenu} menuItems={employeeMenuItems} />}
      topbar={<Topbar title={pageTitles[activeMenu]} />}
    >
      {/* ================= DASHBOARD ================= */}
      {activeMenu === "dashboard" && (
        <>
          <SectionContainer title="Today's Status">
            <Card>
              <div className="flex-row">
                <div>
                  <p style={{ color: "var(--text-secondary)", margin: "0 0 8px 0", fontSize: "0.95rem" }}>Current Status</p>
                  <h2 style={{ margin: 0, fontSize: "1.75rem", color: "var(--text-primary)" }}>{status}</h2>
                </div>
                
                <div style={{ display: "flex", gap: "15px" }}>
                  <button onClick={handleCheckIn} className="ui-button" style={{ backgroundColor: "var(--primary-color)" }}>
                    <FiLogIn /> Check In
                  </button>
                  <button onClick={handleCheckOut} className="ui-button" style={{ backgroundColor: "var(--danger-color)", borderColor: "var(--danger-color)", color: "white" }}>
                    <FiLogOut /> Check Out
                  </button>
                </div>
              </div>
            </Card>
          </SectionContainer>

          <div style={{ marginTop: "32px", display: "flex", flexDirection: "column", gap: "24px" }}>
            <SectionContainer title="My Overview">
              <div className="metrics-grid">
                <MetricCard title="Present Days" value={present} icon={<FiCheckCircle />} colorClass="success" />
                <MetricCard title="Absent Days" value={absent} icon={<FiXCircle />} colorClass="danger" />
                <MetricCard title="Late Days" value={late} icon={<FiClock />} colorClass="warning" />
              </div>
            </SectionContainer>
          </div>
        </>
      )}

      {/* ================= HISTORY ================= */}
      {activeMenu === "history" && (
        <Card title="My Attendance Records">
          <Table columns={historyColumns} data={attendance} />
        </Card>
      )}

      {/* ================= NOTIFICATIONS ================= */}
      {activeMenu === "notifications" && (
        <Card title="Inbox">
          {notifications.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px", color: "var(--text-secondary)" }}>
              <FiBell size={48} style={{ opacity: 0.5, marginBottom: "16px" }} />
              <p style={{ fontSize: "1.1rem" }}>You're all caught up! No new notifications.</p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {notifications.map((msg, i) => (
                <div key={i} style={{ padding: "20px", backgroundColor: "var(--primary-light)", borderRadius: "var(--radius-md)", borderLeft: "4px solid var(--primary-color)" }}>
                  <p style={{ margin: 0, color: "var(--text-primary)", fontWeight: 500 }}>{msg}</p>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}
    </Layout>
  );
}

export default EmployeeDashboard;