import axios from "axios";

// ✅ CREATE AXIOS INSTANCE
const API = axios.create({
  baseURL: "http://127.0.0.1:8000",
  headers: {
    "Content-Type": "application/json",
  },
});

// ================= LOGIN =================
export const login = async (data) => {
  return await API.post(
    `/login?username=${encodeURIComponent(
      data.username
    )}&password=${encodeURIComponent(data.password)}`
  );
};

// ================= REGISTER =================
export const register = async (data) => {
  return await API.post(
    `/register-company?company_name=${encodeURIComponent(
      data.company_name
    )}&username=${encodeURIComponent(
      data.username
    )}&password=${encodeURIComponent(data.password)}`
  );
};

// ================= ADD EMPLOYEE (UPDATED ✅) =================
export const addEmployee = async (data, token) => {
  return await API.post(
    `/add-employee?username=${encodeURIComponent(
      data.username
    )}&password=${encodeURIComponent(
      data.password
    )}&department=${encodeURIComponent(data.department)}`,
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
};

// ================= DELETE EMPLOYEE =================
export const deleteEmployee = (username, token) =>
  API.delete(
    `/delete-employee?username=${encodeURIComponent(username)}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

// ================= GET EMPLOYEES =================
export const getEmployees = async (token) => {
  return await API.get("/employees", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

// ================= CHECK-IN =================
export const checkIn = async (token) => {
  return await API.post(
    "/check-in",
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
};

// ================= CHECK-OUT =================
export const checkOut = async (token) => {
  return await API.post(
    "/check-out",
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
};

// ================= MY ATTENDANCE =================
export const getMyAttendance = async (token) => {
  return await API.get("/my-attendance", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

// ================= SET RULES =================
export const setRules = async (data, token) => {
  return await API.post(
    `/set-rules?check_in_start=${encodeURIComponent(
      data.start
    )}&check_in_end=${encodeURIComponent(
      data.end
    )}&check_out_time=${encodeURIComponent(data.out)}`,
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
};

// ================= GET RULES =================
export const getRules = (token) =>
  API.get("/rules", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

// ✅ EXPORT DEFAULT
export default API;
export const getTodaySummary = (token) =>
  API.get("/today-summary", {
    headers: { Authorization: `Bearer ${token}` },
  });